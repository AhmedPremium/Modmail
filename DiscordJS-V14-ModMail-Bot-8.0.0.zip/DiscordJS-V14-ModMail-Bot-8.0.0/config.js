module.exports = {
    client: {
        token: 'MTE5Nzk2MjM0NzM2MTM1Nzk3Nw.GJvP_Q.I_-f2l4Y3j2zOzP_u05F6Pozm28STDOwCB-EyE', // ← Your bot token (.env IS RECOMMENDED)
        id: '1197962347361357977' // ← Your bot ID
    },
    modmail: {
        guildId: '1158805933602902178', // ← Your server ID
        categoryId: '1182007808741347398', // ← The modmail category ID
        staffRoles: ['1015137860220878888'], // ← The modmail staff roles IDs
        mentionStaffRolesOnNewMail: true // ← Mention staff roles when there is a new mail?
    },
    logs: {
        webhookURL: 'https://discord.com/api/webhooks/1196090999852773428/qbTqq4G6WZiNbkflHm2XivD-Cet-DPMmN6k2GH6rb0jzVBT1D71vV26KXyMaxkOOnQZs' // ← The logging webhook URL (OPTIONAL) (.env IS RECOMMENDED)
    }
};